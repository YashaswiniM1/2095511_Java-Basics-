package hands_on_2;
import java.util.*;
import java.util.Date;
import java.time.*;
import java.text.*;
public class MethodClasses 
	{
		static Scanner scan = new Scanner(System.in);
		static List<String>CompanyName = new ArrayList<String>();
		static List<String>EmployeeName = new ArrayList<String>();
		static List<Integer>EmployeeID = new ArrayList<Integer>();
		static List<Long>PhoneNumber = new ArrayList<Long>();
		static List<String>E_MailID = new ArrayList<String>();
		static List<Integer>Rooms = new ArrayList<Integer>();
		static List<String>CheckInDate = new ArrayList<String>();
		static int total_rooms = 80;
		static int AC_Rooms=40;
		static int NON_AC_Rooms=40;
		static int no_of_reg = 0;
		static int AC_count_of_rooms = 0;
		static int Non_AC_count_of_rooms = 0;
		private Date joinDate;
		static long difference_In_Days;
		//guesthouseBooking demo = new guesthouseBooking();
		
		//Main Method
		public static void main(String args[])
			{
				System.out.println("   Welcome to Hotel JAVA!  ");
				System.out.println("");
				System.out.println("         MENU        ");
				System.out.println("=====================================================");
			    System.out.println("1. Registeration Process - To start with new registration!");
			    System.out.println("2. Room Details - Book a room, check room status and availabilities!");
			    System.out.println("3. All booking details of the rooms in the hotel!");
			    System.out.println("4. Email change or updation!");
			    System.out.println("5. All Bookings Info!");
			    System.out.println("6. All Customers Info!");
			    System.out.println("7. Quit!");
			    System.out.println("");
			    System.out.println("Select an option:");
			    Scanner scan = new Scanner(System.in);
			    
				//Menu();
			    int option = scan.nextInt();
			    switch (option) 
			    {
			      case 1:
		        	  System.out.println("Please enter your details here!");
		        	  RegisterDetails();
		        	  scan.nextLine();
		              break;
			      case 2:
		        	  System.out.println("How many Rooms do you wish to book?");
		        	  scan.nextLine();
		        	  RoomBooking();
		        	  break;
		          case 3:
		              System.out.println("Fetching the data of all available rooms...");
		              scan.nextLine();
		              RoomInfo();
		              break;
		          case 4:
		        	  System.out.println("Kindly update your new Phone Number or E-mail here!");
		        	  scan.nextLine();
		        	  UpdateInfo();
		        	  break;
		         case 5:
		        	  System.out.println("Fetching all the bookings for specific date....");
		        	  scan.nextLine();
		        	  allBookings();//BookingsSpecificTime();
		        	  break;
		          case 6:
		              System.out.println("Fetching the inforamtion of all Customers...");
		              scan.nextLine();
		              Customers_Info_Disp();
		              break;    
		          case 7:
		           	  System.out.println("Exit Process...");
		           	  scan.nextLine();
		           	  Quit();
		          	  break;
		          default:
		          	  System.out.println("Invalid Option");
		          	  break;
			    }
			}
		
		//Registering the information of a Customer
		static void RegisterDetails()
		{
			System.out.println("Please enter your Company Name : ");
			CompanyName.add(scan.next());
			scan.nextLine();
			
			System.out.println("Please enter your Name : ");
			EmployeeName.add(scan.nextLine());
			
			System.out.println("Please enter your Employee ID : ");
			EmployeeID.add(scan.nextInt());
			
			System.out.println("Please enter your Phone Number : ");
			PhoneNumber.add(scan.nextLong());
			
			System.out.println("Please enter your E-mail ID : ");
			E_MailID.add(scan.next());
			
			scan.nextLine();
			
			LocalDate l_date = LocalDate.now(); 
			System.out.println("Current date: " + l_date);
			
			no_of_reg++;
			
			System.out.println("Please select an option: ");
			System.out.println("1. I want to register as a new customer.");
			System.out.println("2. Quit");
			int reg = scan.nextInt();
			if(reg == 1)
			{
				RegisterDetails();
			}
			else if(reg == 2)
			{
				System.out.println("Thank You!");
			}
			else
			{
				System.out.println("Invalid! Please try again.");
			}
			
			scan.nextLine();
			System.out.println("Please select an option: ");
			System.out.println("1. I would like to book a Room.");
			System.out.println("2. I would like to open Menu.");
			System.out.println("3. Quit");
			int a = scan.nextInt();
			if(a == 1)
			{
				RoomBooking();
			}
			else if(a == 2)
			{
				MethodClasses.main(null);
			}
			else
			{
				System.out.println("Thank You!");
			}
		}
		
		//Booking a Room
		static void RoomBooking()	{
			System.out.println("Please select an option: ");
			System.out.println("1. Continue with Booking the Rooms.");
			System.out.println("2. Menu");
			int b = scan.nextInt();
			if(b == 1)
			{
				int n,i;
				System.out.println("Please select the type of Room you want: ");
				System.out.println("1. AC Room");
				System.out.println("2. Non-AC Room");
				int y=scan.nextInt();
				if(y==1)
				{
					System.out.println("Per AC Room would cost around Rs 1000 per day.");
					System.out.println("Facilites provided are: ");
					System.out.println("TV with cable connection, Wi-Fi, Hot Water, Laundry Service and Food(Breakfast, Lunch and Dinner)");
					scan.nextLine();
					System.out.println("Please select an option: ");
					System.out.println("1. Continue to book AC Room.");
					System.out.println("2. Menu");
					int h = scan.nextInt();
					if(h==1)
					{
						System.out.println("Please enter the number of Rooms: ");
						int no = scan.nextInt();
						Rooms.add(no);
						for(i=1; i<=no; i++)
						{
							if(AC_count_of_rooms>AC_Rooms)
							{
								System.out.println("Rooms not available.");
							}
							else
								AC_count_of_rooms++;
						}
						System.out.println("You have booked "+ no+" number of AC rooms");
						System.out.println("The total number of AC rooms being booked :"+AC_count_of_rooms);
						date();
						System.out.println("Thank You, your booking is been confirmed.");
						System.out.println("Vacant rooms count : " + (total_rooms-(AC_count_of_rooms+Non_AC_count_of_rooms)));
						Billing();
						System.out.println(Rooms.toString());
						Quit();
					}
					else
					{
						System.out.println("Invalid Operation!");
						MethodClasses.main(null);
					}
				}
				else
				{
					System.out.println("Per Non-AC Room would cost around Rs 750 per day.");
					System.out.println("Facilites provided are: ");
					System.out.println("TV with cable connection, Wi-Fi, Laundry Service and Food(Breakfast, Lunch and Dinner)");	
					scan.nextLine();
					System.out.println("Please select an option: ");
					System.out.println("1. Continue to book Non-AC Room.");
					System.out.println("2. Menu");
					int g = scan.nextInt();
					if(g==1)
					{
						scan.nextLine();
						System.out.println("Please enter the number of Rooms: ");
						n = scan.nextInt();
						Rooms.add(n);
						for(i=1; i<=n; i++)
						{
							if(Non_AC_count_of_rooms>=NON_AC_Rooms)
							{
								System.out.println("Rooms not available.");
							}
							else
								Non_AC_count_of_rooms++;
						}
						System.out.println("You have booked "+ n+" number of rooms");
						System.out.println("The total number of Non-AC rooms being booked :"+Non_AC_count_of_rooms);
						date();
						System.out.println("Thank You, your booking is been confirmed.");
						System.out.println("Vacant rooms count : " + (total_rooms-(Non_AC_count_of_rooms+AC_count_of_rooms)));
						Billing();
						Quit();
					}
					else
					{
						System.out.println("Invalid Operation!");
						MethodClasses.main(null);
					}
				}
				System.out.println(Rooms.toString());
			}
			else if(b == 2)
			{
				MethodClasses.main(null);
			}
			else
			{
				System.out.println("Invalid! Plaese try again.");
			}
		}
		
		
		//Exit process
		static void Quit()
		 {
			Scanner sc=new Scanner(System.in);
			System.out.println("Please select an option: ");
			System.out.println("1. Continue with Exit Process.");
			System.out.println("2. Menu");
			int c = scan.nextInt();
			if(c == 1)
			{
				System.out.println(" Thank You, I hope you enjoyed the facilites provided by us. "); 
				System.out.println(" Hope to see you again! ");
		    	System.out.println(" HAVE A GOOD DAY! ");
		    	sc.nextLine();
			}
			else if(c == 2)
			{
				MethodClasses.main(null);
			}
			else
			{
				System.out.println("Invalid! Please try again.");
			}
		}
		
		//Room information with facilites
		static void RoomInfo()
		{
			System.out.println("Please select an option: ");
			System.out.println("1. Continue checking the AC room details.");
			System.out.println("2. Continue checking the Non-AC room details.");
			System.out.println("3. Menu");
			int d = scan.nextInt();
			if(d == 1)
			{
				for(int i=1; i<=AC_count_of_rooms; i++)
				{
					System.out.println("Room number " + i + " Occupied.");
				}
				System.out.println("Vacant rooms count : " + (total_rooms-(AC_count_of_rooms+Non_AC_count_of_rooms)));
				Quit();
			}
			else if (d == 2)
			{
				for(int i=1; i<=Non_AC_count_of_rooms; i++)
				{
					System.out.println("Room number " + i + " Occupied.");
				}
				System.out.println("Vacant rooms count : " + (total_rooms-(Non_AC_count_of_rooms+AC_count_of_rooms)));
				Quit();
			}
			else if (d == 3)
			{
				MethodClasses.main(null);
			}
			else 
			{
				System.out.println("Invalid! Plaese try again.");
			}
		}
		
		//Updating a new Phone Number 
		static void UpdateInfo()
		{
			System.out.println("Please select an option: ");
			System.out.println("1. Continue with Phone Number or E-mail updation.");
			System.out.println("2. Menu");
			int e = scan.nextInt();
			if(e == 1)
			{
				//RegisterDetails();
				System.out.println("Please select an option: ");
				System.out.println("1. Continue with Phone Number update.");
				System.out.println("2. Continue with E-mail update.");
				int z = scan.nextInt();
				if(z == 1)
				{
					System.out.println("Please enter your new mobile number: ");
					int index = PhoneNumber.indexOf(PhoneNumber.add(scan.nextLong()));
					//System.out.println("Your company name : " + CompanyName.toString());
					//System.out.println("Your name : " + EmployeeName.toString());
					//System.out.println("Your Employee ID : " + EmployeeID.toString());
					System.out.println("Your old and updated mobile number : " + PhoneNumber.toString());
					Quit();
				}
				else if(z == 2)
				{
					System.out.println("Please enter your new email: ");
					int index = E_MailID.indexOf(E_MailID.set(0,scan.next()));
					//System.out.println("Your company name : " + CompanyName.toString());
					//System.out.println("Your name : " + EmployeeName.toString());
					//System.out.println("Your Employee ID : " + EmployeeID.toString());
					//System.out.println("Your mobile number : " + PhoneNumber.toString());
					System.out.println("Your updated email_ID : " + E_MailID.toString());
					Quit();
				}
				else
				{
					System.out.println("Invalid Operation!");
				}
				
			}
			else if (e == 2)
			{
				MethodClasses.main(null);
			}
			else
			{
				System.out.println("Invalid! Plaese try again.");
			}
		}
		
		//Displaying all the Customers Information
		static void Customers_Info_Disp()
		{
			System.out.println("Please select an option: ");
			System.out.println("1. Continue to fetch the details of all customers.");
			System.out.println("2. Menu");
			int f = scan.nextInt();
			if(f == 1)
			{
				System.out.println("Your Company Name : " + CompanyName.toString());
				System.out.println("Your Name : " + EmployeeName.toString());
				System.out.println("Your Employee ID : " + EmployeeID.toString());
				System.out.println("Your Phone Number : " + PhoneNumber.toString());
				System.out.println("Your E-mail ID: "+ E_MailID.toString());
				Quit();
			}
			else if (f == 2)
			{
				MethodClasses.main(null);
			}
			else
			{
				System.out.println("Invalid! Plaese try again.");
			}
		}	
		static void date()
		{
			 System.out.println("Check in Date: ");
			 String jd = scan.next();
			 CheckInDate.add(jd);
			 LocalDate joinDate=LocalDate.parse(jd);
			 System.out.println("Check in Date is "+joinDate);
			       
			 System.out.println("Enter check out date: ");
		     String s1=scan.next();
		     LocalDate todaysDate = LocalDate.now();
		     System.out.println("Current date is "+todaysDate);
		     
		     LocalDate entered_date = LocalDate.parse(s1);
		     System.out.println("Check out date is "+entered_date);
		     //LocalDate l_date = LocalDate.now();  

		     if(todaysDate.compareTo(entered_date)>0)
		     {
		         System.out.println("Room not found.");
		     }
		     if(todaysDate.compareTo(entered_date)<0)
		     {
		         System.out.println("Rooms available.");
		     }
		     MethodClasses.findDifference(jd, s1);
		}
		static void findDifference(String jd, String s1)
		{
			
			SimpleDateFormat sdf= new SimpleDateFormat("yyyy-MM-dd");
			try {
				Date d1 = sdf.parse(jd);
				Date d2 = sdf.parse(s1);
				long difference_In_Time= d2.getTime() - d1.getTime();
				long difference_In_Years= (difference_In_Time/ (1000l * 60 * 60 * 24 * 365));
				difference_In_Days= (difference_In_Time/ (1000 * 60 * 60 * 24))% 365;
				System.out.print("Difference "+ "between two dates is: ");
				System.out.println(difference_In_Years+ " years, "+ difference_In_Days+ " days");
			}
			catch (ParseException e) {
				e.printStackTrace();
			}
		}
		/*static void BookingsSpecificTime()
		{
			System.out.println("Number of days the rooms being booked: "+difference_In_Days);
		}*/
		static void Billing()
		{
			System.out.println("Please confirm to proceed with Billing: ");
			System.out.println("1. Continue with further booking process with AC room.");
			System.out.println("2. Continue with further booking process with Non-AC room.");
			System.out.println("3. Menu");
			int v = scan.nextInt();
			if(v == 1)
			{
				float AC_Billing=difference_In_Days*1000*AC_count_of_rooms;
				System.out.println("Your total bill for "+AC_count_of_rooms+" room/rooms is "+AC_Billing+".");
			}
			else if(v==2)
			{
				float Non_AC_Billing=difference_In_Days*750*Non_AC_count_of_rooms;
				System.out.println("Your total bill for "+Non_AC_count_of_rooms+" room/rooms is "+Non_AC_Billing+".");
			}
			else if(v==3)
			{
				MethodClasses.main(null);
			}
			else
			{
				System.out.println("Invalid! Plaese try again.");
			}
		}
		static void allBookings()
	    {
			System.out.println("Please enter the date you want the details.");
	        String x = scan.next();
	        int index1 = CheckInDate.indexOf(x);
	        System.out.println(CheckInDate.toString());
	        if(index1 >= 0)
	        {
	            System.out.println(Rooms.get(index1));
	        }
	        else
	        {
	            System.out.println("There are no bookings on the given date.");
	        }
	        System.out.println("Please select an option \n1.Go to the menu \n2. Quit");
	        int d3 = scan.nextInt();
	        if(d3==1)
	        {
	        	MethodClasses.main(null);
	        }
	        else
	            Quit();
	    }
		
}
