package com.CxMain.connect;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConCustomer {
	static Connection connection;
	public static Connection createconn()
	{
		try
		{
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/customerdetails", "root", "Yashu28#ts");
		}
		catch (Exception e)
		{
			System.out.println("Error in Connection: "+e);
		}
		return connection;
	} 
	public static void closeConne()
	{
		try
		{
			connection.close();
		}
		catch (Exception e)
		{
			System.out.println("Error in Connection Close: "+e);
		}
	}

}
