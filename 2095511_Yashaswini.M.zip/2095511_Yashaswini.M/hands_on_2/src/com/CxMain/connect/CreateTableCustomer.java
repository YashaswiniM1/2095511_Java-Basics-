package com.CxMain.connect;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateTableCustomer {
	public static void main(String[] args) throws SQLException
	{
		Driver driver = new com.mysql.cj.jdbc.Driver();
		DriverManager.registerDriver(driver);		
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/CustomerDetails", "root", "Yashu28#ts");
		try{
			String qry = "create table CxDetails (ID int primary key, NAME varchar(30), AGE int, ADDRESS varchar(80), E_MAIL varchar(30), MOBILE int, CHECK_IN_DATE Date)";
			Statement statement = connection.createStatement();
			statement.execute(qry); 
		}catch(Exception e)	{
		System.out.println("Error: "+e);
		}
	}

}
