package com.CxMain;

import java.util.List;
import java.util.Scanner;

import com.CxMain.dao.Customer;
import com.CxMain.dao.CustomerDao;
import com.CxMain.dao.CustomerDaoImpl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainMethod {
	static Scanner scanner = new Scanner(System.in);
	private static int  room_count = 0;

	public static void main(String[] args) throws ParseException {
		CustomerDao custDao = new CustomerDaoImpl();
		do {
			System.out.println("Select the Options below :");
			System.out.println(
					" 1. Register � Register a new customer. \n 2. Book � Book a room. \n 3. Check Status � Check for the rooms present status. \n 4. Email � Change/Update an email address for the customer. \n "
							+ "5. All Bookings on a particular date. \n 6. All customers details \n 7. Exit \n");
			int option = scanner.nextInt();
			switch (option) {
			case 1:
				Customer customer = inputMet();
				int result = custDao.addCustomer(customer);
				if (result > 0) {
					System.out.println("Customer details added successfully and Registered....");
				} else {
					System.out.println("Try to register again....");
				}
				break;
			case 2:
				scanner.nextLine();
				System.out.println("Enter number of rooms you wish to have: ");
				room_count = scanner.nextInt();
				int RoomBook= custDao.BookCustomerRoom()*room_count;
				System.out.println("The total cost you have to pay is: "+RoomBook);
				break;
			case 3:
				int i=0;
				List<Customer> cList3 = custDao.getAllCustomer();
				for(Customer people :cList3) {
					i++;
				}
				int room=50-room_count;
				if(room>0)
					System.out.println("Number of vacant room are: "+room);
				else
					System.out.println("No vacant room is available");
				break;
			case 4:
				Customer customerup= update();
				int r1 = custDao.updateCustomer(customerup);
				break;
			case 5: 
				List<Customer> cList1 = custDao.getCustomerByDate();
				for(Customer custD :cList1) {
					System.out.println(custD);
				}
				break;
			case 6:
				List<Customer> cList = custDao.getAllCustomer();
				for(Customer cust :cList){
					System.out.println(cust);
				}
				break;
			case 7:
				System.out.println(" Thank You, I hope you enjoyed the facilites provided by us. "); 
				System.out.println(" Hope to see you again! ");
		    	System.out.println(" HAVE A GOOD DAY! ");
		    	scanner.nextLine();
				break;
			default:
				System.out.println("Invalid Operation, try again!");
				break;
			}
			System.out.println("Do you want to Continue  1. Yes \t 2. No");
		} while (scanner.nextInt() == 1);
		System.out.println("Thank You..........! \n Have a nice day....!");
	}

	static Customer inputMet() throws ParseException {
		System.out.println("Enter customer Details :");
		System.out.print("ID :");
		int id = scanner.nextInt();
		System.out.println("Name : ");
		String name = scanner.next();
		System.out.print("Age :");
		int age = scanner.nextInt();
		System.out.println("Address : ");
		String address = scanner.next();
		System.out.println("Email : ");
		String email = scanner.next();
		System.out.println("Mobile : ");
		long mobile = scanner.nextLong();
		System.out.println("Check In Date (dd/MM/yyyy): ");
		String jd = scanner.next();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Date checkinDate = sdf.parse(jd);
		Customer customer = new Customer(id, name, age, address, email, mobile, checkinDate);
		return customer;
	}
	static Customer update() {
		System.out.println("Enter Associates ID: ");
		int id3 = scanner.nextInt();
		System.out.println("Enter Associate Email: ");
		String email1 = scanner.next();
		Customer Cust= new Customer(id3, email1);
		return Cust;
	}


}
