package com.CxMain.dao;

import java.util.List;

public interface CustomerDao {
	public int addCustomer(Customer customer);
	public List<Customer> getAllCustomer();
	public Customer getCustomerById(int id);
	public List<Customer> getCustomerByDate();
	public int updateCustomer(Customer customer);
	public int BookCustomerRoom();
	public int deleteCustomer(int id);

}
