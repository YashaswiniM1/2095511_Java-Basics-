package com.CxMain.dao;

import java.util.ArrayList;
import java.util.List;

import com.CxMain.connect.ConCustomer;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.util.*;

public class CustomerDaoImpl implements CustomerDao {
	Connection connection;
	static int price;
	
	public CustomerDaoImpl() {
		this.connection = ConCustomer.createconn();
	}
	
	@Override
	public int addCustomer(Customer customer) {
		int result = 0;
		try {
			PreparedStatement ps = connection.prepareStatement("insert into CxDetails values(?,?,?,?,?,?,?)");
			ps.setInt(1, customer.getId());
			ps.setString(2, customer.getName());
			ps.setInt(3, customer.getAge());
			ps.setString(4, customer.getAddress());
			ps.setString(5, customer.getEmail());
			ps.setLong(6, customer.getMobile());
			java.sql.Date jd = new java.sql.Date(customer.getCheckinDate().getTime());
			ps.setDate(7, jd);
			result = ps.executeUpdate();
		} catch (Exception e) {
			System.out.println("Error in Add CxDetails ...: " + e);
		}
		return result;
	}

	@Override
	public List<Customer> getAllCustomer() {
		List<Customer> cList = new ArrayList<>();
		try
		{
			Statement st = connection.createStatement();
			ResultSet rs = st.executeQuery("select * from CxDetails");
			
			while(rs.next())
			{
				Customer customer = new Customer();
				customer.setId(rs.getInt(1));
				customer.setName(rs.getString(2));
				customer.setAge(rs.getInt(3));
				customer.setAddress(rs.getString(4));
				customer.setEmail(rs.getString(5));
				customer.setMobile(rs.getLong(6));
				customer.setCheckinDate(rs.getDate(7));
				cList.add(customer);
			}
		}
		catch(Exception e)
		{
			System.out.println("Error in getting all Customer Details "+e);	
		}
		return cList;
	}

	@Override
	public Customer getCustomerById(int id) {
		Customer customer = new Customer();
		try
		{
			PreparedStatement pst = connection.prepareStatement("select * from Cxdetails where id=?");
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			
			while(rs.next())
			{
				customer.setId(rs.getInt(1));
				customer.setName(rs.getString(2));
				customer.setAge(rs.getInt(3));
				customer.setAddress(rs.getString(4));
				customer.setEmail(rs.getString(5));
				customer.setMobile(rs.getLong(6));
				customer.setCheckinDate(rs.getDate(7));
			}
		}
		catch(Exception e)
		{
			System.out.println("Error in getting Customer Details by ID "+e);	
		}
		return customer;
	}

	@Override
	public int updateCustomer(Customer customer) {
		int a = 0;
		try {
			String qry = "update CxDetails set email=? where id=?";
			PreparedStatement pss = connection.prepareStatement(qry);
			pss.setInt(2, customer.getId());
			pss.setString(1, customer.getEmail());
			a = pss.executeUpdate();
			if(a>0)
			{
				System.out.println(a+" Records are Updated......");
			}
			else
			{
				System.out.println("Records are not Updated......");
			}
		} 
		catch (Exception e)
		{
			System.out.println("Error in Updating Customer Details...: " + e);
		}
		return 0;
	}

	@Override
	public int deleteCustomer(int id) {
		try
		{
		String qry = "delete from CxDetails where id=?";
		PreparedStatement ps = connection.prepareStatement(qry);
		ps.setInt(1, id);
		int a = ps.executeUpdate();
		if (a > 0) 
		{
			System.out.println(a + " Records Deleted....");
		} 
		else 
		{
			System.out.println("Records Not Deleted....");
		}
		}
		catch(Exception e)	
		{
			System.out.println("Error: "+e);
		}
		return 0;
	}

	@Override
	public List<Customer> getCustomerByDate() {
		List<Customer> cList1 = new ArrayList<>();
		String date1;
		String date2;
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the first date:");
		date1=sc.nextLine();
		System.out.println("Enter the second date:");
		date2=sc.nextLine();
		Customer customer = new Customer();
		try {
			PreparedStatement pst = connection.prepareStatement("select * from CxDetails where CheckInDate between ? and ?;");
			java.sql.Date jd1 = new java.sql.Date(customer.getCheckinDate().getTime());
			pst.setDate(1, jd1);
			java.sql.Date jd2 = new java.sql.Date(customer.getCheckinDate().getTime());
			pst.setDate(2, jd2);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				customer.setId(rs.getInt(1));
				customer.setName(rs.getString(2));
				customer.setAge(rs.getInt(3));
				customer.setAddress(rs.getString(4));
				customer.setEmail(rs.getString(5));
				customer.setMobile(rs.getLong(6));
				customer.setCheckinDate(rs.getDate(7));
				cList1.add(customer);
			}
		} 
		catch (Exception e) 
		{
			System.out.println("Error in Get By Date : " + e);
		}
		return cList1;
	}

	@Override
	public int BookCustomerRoom() {
		System.out.println("Choose a type of room: \n 1. AC Rooms \n 2. Non-AC Rooms");
		Scanner scan =new Scanner(System.in);
		int choice = scan.nextInt();
		switch(choice) {
		case 1:
			price=1000;
			System.out.println("Choose the service you wish: \n 1. Wifi \n 2. Hot_Water \n 3. T.V. \n 4. Laundry service");
			int ch1=scan.nextInt();
			switch(ch1) {
			case 1:
				System.out.println("Wifi service will be provided to you.");
				price=price+200;
				break;
			case 2:
				System.out.println("Hot water service will be provided to you.");
				price=price+100;
				break;
			case 3:
				System.out.println("T.V. service will be provided to you.");
				price=price+50;
				break;
			case 4:
				System.out.println("Laundry service will be provided to you.");
				price=price+200;
				break;
			}
			break;
		case 2:
			price=750;
			System.out.println("Choose the service you want: \n 1. Wifi \n 2. Hot_Water \n 3. T.V. \n 4. Laundry service");
			int ch2=scan.nextInt();
			switch(ch2) {
			case 1:
				System.out.println("Wifi service will be provided to you.");
				price=price+200;
				break;
			case 2:
				System.out.println("Hot water service will be provided to you.");
				price=price+100;
				break;
			case 3:
				System.out.println("T.V. service will be provided to you.");
				price=price+50;
				break;
			case 4:
				System.out.println("Laundry service will be provided to you.");
				price=price+200;
				break;
			}
			break;
		}
		return price;
	}
}
