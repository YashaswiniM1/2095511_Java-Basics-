package com.CxMain.dao;

import java.util.Date;

public class Customer {

	private int id;
	private String name;
	private int age;
	private String address;
	private String email;
	private long mobile;
	private Date checkinDate;
	
	public Customer() {
		super();
	}
	public Customer(int id, String name, int age, String address, String email, long mobile, Date checkinDate) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.address = address;
		this.email = email;
		this.mobile = mobile;
		this.checkinDate = checkinDate;
	}
	public Customer(int id3, String email1) {
		super();
		this.id = id3;
		this.email = email1;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getMobile() {
		return mobile;
	}
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	public Date getCheckinDate() {
		return checkinDate;
	}
	public void setCheckinDate(Date checkinDate) {
		this.checkinDate = checkinDate;
	}
	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", age=" + age + ", address=" + address + ", email=" + email
				+ ", mobile=" + mobile + ", checkinDate=" + checkinDate + "]";
	}



}
