package com.cognizant.shapes;

public class AreaCalculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle l=new Rectangle();
		l.length=10;
		l.breadth=2;
		l.calculateArea();
	}

}
