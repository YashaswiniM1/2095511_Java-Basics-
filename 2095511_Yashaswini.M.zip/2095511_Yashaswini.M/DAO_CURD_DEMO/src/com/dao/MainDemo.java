package com.dao;
import java.util.List;
import java.util.Scanner;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.dao.da1.Asssociates;
import com.dao.da1.AsssociatesDao;
import com.dao.da1.AsssociatesDaoImpl;

public class MainDemo {
	static Scanner scan=new Scanner(System.in);
	public static void main(String[] args) throws ParseException {
		
		
		AsssociatesDao asDao = new AsssociatesDaoImpl();
		do {
			System.out.println("Select the Options below :");
			System.out.println(" 1. Add Asssociates \n 2. View All Asssociates \n 3. View By Asssociate ID \n 4. Update Associates \n 5. Delete Asssociates \n 6. Exit");
			int option = scan.nextInt();
			
			switch (option) {
			case 1:
				Asssociates associates = inputMet();
				int result = asDao.addAsssociates(associates);
				if(result>0)
				{
					System.out.println("Associate's Details Added Successfully.....");
				}
				else
				{
					System.out.println("Try to Add Again......");
				}
				break;
			case 2:
				List<Asssociates> asssoList = asDao.getAllAsssociates();
				for(Asssociates assso :asssoList){
					System.out.println(assso);
				}
				break;
			case 3:
				System.out.println("Enter associate ID: ");
				int id = scan.nextInt();
				Asssociates asssociates2= asDao.getAsssociatesById(id);
				System.out.println(asssociates2);
				break;
			case 4:
				Asssociates associates1= update();
				int result1 = asDao.updateAsssociates(associates1);
				break;
			case 5:
				System.out.println("Enter Associate ID: ");
				int id2 = scan.nextInt();
				int asssociates3= asDao.deleteAsssociates(id2);
				break;
			default:
				System.out.println("Invalid operation, please try again.");
				break;
		}
		System.out.println("Do you want to Continue  1. Yes \t 2. No");
	} 
		while (scan.nextInt() == 1);
		System.out.println("Thank You!");
		
	}

	static Asssociates inputMet() throws ParseException{ 
		System.out.println("Enter Associates Details :");
		System.out.print("ID :");
		int id = scan.nextInt();
		System.out.println("Name : ");
		String name = scan.next();
		System.out.println("Email : ");
		String email = scan.next();
		System.out.println("Mobile : ");
		long mobile = scan.nextLong();
		System.out.println("Join Date (dd/MM/yyyy): ");
		String jd = scan.next();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Date joinDate = sdf.parse(jd);
		Asssociates associates = new Asssociates(id, name, email, mobile, joinDate);
		return associates;
	}
	static Asssociates update() {
		System.out.println("Enter Associates ID: ");
		int id3 = scan.nextInt();
		System.out.println("Enter Associate Email: ");
		String email1 = scan.next();
		Asssociates asDao= new Asssociates(id3, email1);
		return asDao;
	}
}

