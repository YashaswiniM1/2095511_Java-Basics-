package com.dao.connect;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreatetableDemo 
{
	public static void main(String[] args) throws SQLException
	{
		Driver driver = new com.mysql.cj.jdbc.Driver();
		DriverManager.registerDriver(driver);		
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/CustomerDetails", "root", "Yashu28#ts");
		try{
			String qry = "create table asssociates (id int primary key, name varchar(30), email varchar(30), mobile int, joinDate Date)";
			Statement statement = connection.createStatement();
			statement.execute(qry); 
		
		}catch(Exception e)	{
		System.out.println("Error: "+e);
		}
	}
}
