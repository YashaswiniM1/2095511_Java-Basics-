package com.dao.connect;
import java.sql.Connection;
import java.sql.DriverManager;

public class ConneDemo {
	static Connection connection;
	public static Connection createconne()
	{
		try
		{
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/customerdetails", "root", "Yashu28#ts");
		}
		catch (Exception e)
		{
			System.out.println("Error in Connection: "+e);
		}
		return connection;
	} 
	public static void closeConne()
	{
		try
		{
			connection.close();
		}
		catch (Exception e)
		{
			System.out.println("Error in Connection Close: "+e);
		}
	}
}
