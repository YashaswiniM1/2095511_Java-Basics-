package com.dao.da1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.dao.connect.ConneDemo;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;


public class AsssociatesDaoImpl implements AsssociatesDao {
	
	Connection connection;
	public AsssociatesDaoImpl(){
		this.connection = ConneDemo.createconne();
	}
	@Override
	public int addAsssociates(Asssociates asssociates) {
		int result = 0;
		try{
			PreparedStatement ps = connection.prepareStatement("Insert into asssociates values(?,?,?,?,?)");
			ps.setInt(1, asssociates.getId());
			ps.setString(2, asssociates.getName());
			ps.setString(3, asssociates.getEmail());
			ps.setLong(4, asssociates.getMobile());
			java.sql.Date jd = new java.sql.Date(asssociates.getJoinDate().getTime());
			ps.setDate(5,jd );
			result = ps.executeUpdate();
		}
		catch (Exception e)
		{
			System.out.println("Error in Adding Associates.."+e);
		}
		
		return result;
	}

	@Override
	public List<Asssociates> getAllAsssociates() 
	{
		List<Asssociates> aList = new ArrayList<>();
		try
		{
			Statement st = connection.createStatement();
			ResultSet rs = st.executeQuery("select * from asssociates");
			
			while(rs.next())
			{
				Asssociates asssociates = new Asssociates();
				asssociates.setId(rs.getInt(1));
				asssociates.setName(rs.getString(2));
				asssociates.setEmail(rs.getString(3));
				asssociates.setMobile(rs.getLong(4));
				asssociates.setJoinDate(rs.getDate(5));
				aList.add(asssociates);
			}
		}
		catch(Exception e)
		{
			System.out.println("Error in getting all Associates "+e);	
		}
		return aList;
	}

	@Override
	public Asssociates getAsssociatesById(int id)
	{
		Asssociates asssociates = new Asssociates();
		try
		{
			PreparedStatement pst = connection.prepareStatement("select * from asssociates where id=?");
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			
			while(rs.next())
			{
				asssociates.setId(rs.getInt(1));
				asssociates.setName(rs.getString(2));
				asssociates.setEmail(rs.getString(3));
				asssociates.setMobile(rs.getLong(4));
				asssociates.setJoinDate(rs.getDate(5));
			}
		}
		catch(Exception e)
		{
			System.out.println("Error in getting Associates by ID "+e);	
		}
		return asssociates;
	}

	@Override
	public int updateAsssociates(Asssociates asssociates) {
		int a = 0;
		try {
			String qry = "update asssociates set email=? where id=?";
			PreparedStatement pss = connection.prepareStatement(qry);
			pss.setInt(2, asssociates.getId());
			pss.setString(1, asssociates.getEmail());
			a = pss.executeUpdate();
			if(a>0)
			{
				System.out.println(a+" Records are Updated......");
			}
			else
			{
				System.out.println("Records are not Updated......");
			}
		} 
		catch (Exception e)
		{
			System.out.println("Error in Update Associates...: " + e);
		}
		return 0;
	}

	@Override
	public int deleteAsssociates(int id) 
	{
		try
		{
		String qry = "delete from asssociates where id=?";
		PreparedStatement ps = connection.prepareStatement(qry);
		ps.setInt(1, id);
		int a = ps.executeUpdate();
		if (a > 0) 
		{
			System.out.println(a + " Records Deleted....");
		} 
		else 
		{
			System.out.println("Records Not Deleted....");
		}
		}
		catch(Exception e)	
		{
			System.out.println("Error: "+e);
		}
		return 0;
		}
}

