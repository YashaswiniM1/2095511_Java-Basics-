package com.dao.da1;
import java.util.List;

public interface AsssociatesDao {
	public int addAsssociates(Asssociates asssociates);
	public List<Asssociates> getAllAsssociates();
	public Asssociates getAsssociatesById(int id);
	public int updateAsssociates(Asssociates asssociates);
	public int deleteAsssociates(int id);
	
}
